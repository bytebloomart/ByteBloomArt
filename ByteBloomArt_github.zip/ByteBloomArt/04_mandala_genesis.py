# ============================================================
#  MANDALA GENESIS - ByteBloomArt (kod #9, pygame) - UZUN VIDEO ~70 soniya
#  Faqat pygame kerak. Pyroid 3 da Run bosing. To'xtatish: ekranga bosing.
#
#  HOOK: video tayyor mandala bilan boshlanadi ("Wait for Layer 7"),
#  keyin qora ekran va mandala 7 qatlamda noldan quriladi. Tepada
#  "LAYER n / 7" va progress chiziq. Oxirida tayyor mandala jonlanadi
#  (aylanadi, nafas oladi, ranglar oqadi). Keyin kanal nomi.
# ============================================================
import math
import colorsys
import pygame

# ---------------- SOZLAMALAR ----------------
HOOK_T    = 2.2    # boshidagi tayyor mandala (soniya)
LAYER_T   = 7.0    # har qatlam qurilish vaqti (soniya)
FINAL_T   = 16.0   # oxirida jonli mandala (soniya)
END_T     = 3.0    # kanal nomi kartasi (soniya)
LINE_W    = 2      # chiziq qalinligi (2 aniq, 3 qalin)
SIZE      = 0.42   # o'lcham (0.34 kichik ... 0.44 katta)
HUE_SPEED = 0.05   # oxirgi bosqichda rang oqish tezligi
CHANNEL   = "ByteBloomArt"
LOOP      = False  # True -> tugagach boshidan boshlanadi
FINAL_STRIDE = 3   # oxirgi bosqichda chiziqlarni siyraklashtirish: 1 = to'liq, 3 = 3x yengil
                   # (telefon qotsa 4 yoki 5 qiling)
FPS       = 30
# --------------------------------------------

pygame.init()
try:
    screen = pygame.display.set_mode((0, 0), pygame.FULLSCREEN)
except Exception:
    screen = pygame.display.set_mode((540, 960))
W, H = screen.get_size()
CX, CY = W / 2, H / 2
R = min(W, H) * SIZE
clock = pygame.time.Clock()
font_big = pygame.font.Font(None, int(W * 0.09))
font_mid = pygame.font.Font(None, int(W * 0.065))
font_small = pygame.font.Font(None, int(W * 0.05))
TAU = 2 * math.pi

PALETTE = [tuple(int(c * 255) for c in colorsys.hsv_to_rgb(i / 256, 0.8, 1.0))
           for i in range(256)]

# ---------- Geometriya: har qatlam = bir xil uzunlikdagi chiziqlar ro'yxati ----------
def rot(p, a):
    c, s = math.cos(a), math.sin(a)
    return (p[0] * c - p[1] * s, p[0] * s + p[1] * c)

def circle(cx, cy, r, m):
    return [(cx + r * math.cos(TAU * i / m), cy + r * math.sin(TAU * i / m))
            for i in range(m + 1)]

def petal(a, d0, d1, w, m):
    half = m // 2
    pts = []
    for j in range(half):                       # bir tomon
        s = j / (half - 1)
        pts.append((d0 + (d1 - d0) * s, w * math.sin(math.pi * s) ** 0.9))
    for j in range(half):                       # ikkinchi tomon
        s = 1 - j / (half - 1)
        pts.append((d0 + (d1 - d0) * s, -w * math.sin(math.pi * s) ** 0.9))
    return [rot(p, a) for p in pts]

def build_layers():
    L = []
    # 1) markaz halqalari
    L.append([circle(0, 0, r, 36) for r in (0.07, 0.13, 0.19)])
    # 2) ichki 12 ta barg
    L.append([petal(TAU * k / 12, 0.18, 0.52, 0.12, 40) for k in range(12)])
    # 3) 12 ta aylana halqasi
    L.append([circle(0.38 * math.cos(TAU * k / 12), 0.38 * math.sin(TAU * k / 12),
                     0.22, 44) for k in range(12)])
    # 4) yulduz ko'pburchak {24/9}
    star = []
    for k in range(24):
        a1, a2 = TAU * k / 24, TAU * (k + 9) / 24
        p1 = (0.75 * math.cos(a1), 0.75 * math.sin(a1))
        p2 = (0.75 * math.cos(a2), 0.75 * math.sin(a2))
        star.append([(p1[0] + (p2[0] - p1[0]) * i / 16, p1[1] + (p2[1] - p1[1]) * i / 16)
                     for i in range(17)])
    L.append(star)
    # 5) tashqi 24 ta barg
    L.append([petal(TAU * (k + 0.5) / 24, 0.62, 0.91, 0.07, 28) for k in range(24)])
    # 6) to'lqin halqalar
    L.append([[((0.94 + 0.035 * math.sin(36 * TAU * i / 160 + ph)) * math.cos(TAU * i / 160),
                (0.94 + 0.035 * math.sin(36 * TAU * i / 160 + ph)) * math.sin(TAU * i / 160))
               for i in range(161)] for ph in (0.0, math.pi)])
    # 7) nuqtalar halqasi (36 ta kichik aylana)
    L.append([circle(0.985 * math.cos(TAU * k / 36), 0.985 * math.sin(TAU * k / 36),
                     0.026, 10) for k in range(36)])
    return L

LAYERS = build_layers()
N_LAYERS = len(LAYERS)
HUES = [0.55, 0.85, 0.12, 0.40, 0.95, 0.60, 0.15]   # har qatlam asosiy rangi
SEGS = sum(len(p) - 1 for layer in LAYERS for p in layer)

def seg_color(li, pi_, npoly, i, m, shift):
    k = int((HUES[li] + 0.15 * i / m + 0.2 * pi_ / npoly + shift) * 256) % 256
    return PALETTE[k]

def to_px(p, ca, sa, sc):
    return (CX + R * sc * (p[0] * ca - p[1] * sa), CY + R * sc * (p[0] * sa + p[1] * ca))

def draw_layer(li, i0, i1, angle=0.0, sc=1.0, shift=0.0, stride=1):
    """Qatlamning i0..i1 oraliqdagi segmentlarini chizadi."""
    ca, sa = math.cos(angle), math.sin(angle)
    polys = LAYERS[li]
    npoly = len(polys)
    for pi_, pts in enumerate(polys):
        m = len(pts) - 1
        if stride == 1:
            idx = range(max(1, i0), min(i1, m) + 1)
        else:                                     # siyrak chizish (tez)
            idx = list(range(stride, m + 1, stride))
            if idx[-1] != m:
                idx.append(m)
        prev = 0
        for i in idx:
            a = i - 1 if stride == 1 else prev
            pygame.draw.line(screen, seg_color(li, pi_, npoly, i, m, shift),
                             to_px(pts[a], ca, sa, sc), to_px(pts[i], ca, sa, sc), LINE_W)
            prev = i

def draw_partial(li, fl, frc):
    """Yarim chizilgan oxirgi segment: chiziq har kadrda silliq o'sadi (qotish yo'q)."""
    polys = LAYERS[li]
    npoly = len(polys)
    for pi_, pts in enumerate(polys):
        m = len(pts) - 1
        if fl >= m or frc <= 0:
            continue
        a, b = pts[fl], pts[fl + 1]
        mid = (a[0] + (b[0] - a[0]) * frc, a[1] + (b[1] - a[1]) * frc)
        pygame.draw.line(screen, seg_color(li, pi_, npoly, fl + 1, m, 0.0),
                         to_px(a, 1.0, 0.0, 1.0), to_px(mid, 1.0, 0.0, 1.0), LINE_W)

def text_center(msg, font, y, color=(255, 255, 255)):
    img = font.render(msg, True, color)
    screen.blit(img, (CX - img.get_width() / 2, y))

def header(label, frac):
    """Tepada: qatlam yozuvi va progress chiziq (Shorts interfeysidan pastroqda)."""
    pygame.draw.rect(screen, (0, 0, 0), (0, int(H * 0.05), W, int(H * 0.11)))
    text_center(label, font_mid, H * 0.06)
    bx, bw, by = W * 0.1, W * 0.8, int(H * 0.11)
    pygame.draw.rect(screen, (50, 50, 50), (int(bx), by, int(bw), 6))
    pygame.draw.rect(screen, (255, 255, 255), (int(bx), by, int(bw * frac), 6))

def run_video():
    t_build0 = HOOK_T
    t_final0 = t_build0 + N_LAYERS * LAYER_T
    t_end0 = t_final0 + FINAL_T
    total = t_end0 + END_T
    state, drawn = None, [0] * N_LAYERS
    frame = 0
    while True:
        for e in pygame.event.get():
            if e.type in (pygame.QUIT, pygame.MOUSEBUTTONDOWN, pygame.KEYDOWN):
                return False
        t = frame / FPS
        if t >= total:
            return True

        if t < t_build0:                                   # 1) HOOK
            if state != "hook":
                state = "hook"
                screen.fill((0, 0, 0))
                for li in range(N_LAYERS):
                    draw_layer(li, 0, 10 ** 6)
                text_center("Python draws this from nothing", font_mid, H * 0.07)
                text_center("Wait for Layer 7", font_big, H * 0.72, (255, 230, 120))
        elif t < t_final0:                                 # 2) QURILISH
            if state != "build":
                state = "build"
                screen.fill((0, 0, 0))
            lt = t - t_build0
            li = min(N_LAYERS - 1, int(lt // LAYER_T))
            frac_layer = min(1.0, (lt - li * LAYER_T) / LAYER_T)
            m = len(LAYERS[li][0]) - 1
            f = m * frac_layer
            target = int(f)
            draw_layer(li, drawn[li], target)
            draw_partial(li, target, f - target)
            drawn[li] = max(drawn[li], target)
            header("LAYER %d / %d" % (li + 1, N_LAYERS), lt / (N_LAYERS * LAYER_T))
        elif t < t_end0:                                   # 3) JONLI FINAL
            ft = t - t_final0
            if state != "final":
                state = "final"
            screen.fill((0, 0, 0))
            sc = 1.0 + 0.03 * math.sin(ft * 2.0)           # nafas
            for li in range(N_LAYERS):
                ang = ft * 0.10 * (1 if li % 2 == 0 else -1) * (0.6 + 0.15 * li)
                draw_layer(li, 0, 10 ** 6, ang, sc, ft * HUE_SPEED, FINAL_STRIDE)
            header("COMPLETE", 1.0)
        else:                                              # 4) OXIRGI KARTA
            if state != "end":
                state = "end"
                screen.fill((0, 0, 0))
                text_center(CHANNEL, font_big, H * 0.44)
                text_center("Python Art  -  Follow for more", font_small, H * 0.52,
                            (180, 180, 180))
        pygame.display.flip()
        clock.tick(FPS)
        frame += 1

while True:
    finished = run_video()
    if not (LOOP and finished):
        break
pygame.quit()
