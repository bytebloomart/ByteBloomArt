# ============================================================
#  ROSE EVOLUTION - ByteBloomArt (kod #8, pygame) - UZUN VIDEO
#  Faqat pygame kerak. Pyroid 3 da Run bosing. To'xtatish: ekranga bosing.
#  Matematik "atirgul egri chiziqlari" (r = cos(k * burchak)) bitta-bitta
#  chizilib chiqadi. Har sahna yangi k qiymati. Taxminan 100 soniya,
#  oxirida kanal nomi chiqadi va dastur o'zi tugaydi.
# ============================================================
import math
import colorsys
import pygame

# ---------------- SOZLAMALAR ----------------
# Har sahna: (n, d) -> k = n / d. Xohlasangiz o'zgartiring/qo'shing/olib tashlang.
SCENES   = [(3, 1), (5, 2), (7, 3), (4, 1), (7, 2), (9, 4), (5, 3), (8, 3)]
DRAW_T   = 10.5    # har sahna chizilish vaqti (soniya)
FADE_T   = 1.5     # sahna oxirida so'nish (soniya)
POINTS   = 2600    # egri chiziq silliqligi
LINE_W   = 2       # chiziq qalinligi (2 aniq, 3 qalin)
SIZE     = 0.42    # shakl o'lchami (0.34 kichik ... 0.44 katta)
HUE_SHIFT = 0.12   # har sahnada rang siljishi
SHOW_LABEL = True  # tepada "k = 5/2" yozuvi
CHANNEL  = "ByteBloomArt"   # oxirgi kartadagi nom
END_T    = 4.0     # oxirgi karta vaqti (soniya)
LOOP     = False   # True bo'lsa video tugamay boshidan boshlanadi
FPS      = 30
# --------------------------------------------

pygame.init()
try:
    screen = pygame.display.set_mode((0, 0), pygame.FULLSCREEN)
except Exception:
    screen = pygame.display.set_mode((540, 960))
W, H = screen.get_size()
CX, CY = W / 2, H / 2
R = min(W, H) * SIZE
clock = pygame.time.Clock()
font_big = pygame.font.Font(None, int(W * 0.09))
font_small = pygame.font.Font(None, int(W * 0.055))

PALETTE = [tuple(int(c * 255) for c in colorsys.hsv_to_rgb(i / 256, 0.8, 1.0))
           for i in range(256)]
SCENE_T = DRAW_T + FADE_T
LAYERS = [(1.00, 0.00, 0.0), (0.66, 0.35, 0.33), (0.36, 0.70, 0.66)]  # (olcham, burilish, rang)
fade = pygame.Surface((W, H))
fade.fill((0, 0, 0))
fade.set_alpha(28)

def text_center(msg, font, y, color=(255, 255, 255)):
    img = font.render(msg, True, color)
    screen.blit(img, (CX - img.get_width() / 2, y))

def curve_points(n, d):
    # r = cos(k*theta), k = n/d, theta 0 .. 2*pi*d (egri yopiq chiqadi)
    k = n / d
    pts = []
    for i in range(POINTS + 1):
        th = 2 * math.pi * d * i / POINTS
        r = math.cos(k * th)
        pts.append((r * math.cos(th), r * math.sin(th)))
    return pts

def run_video():
    scene = -1
    pts, drawn = [], 0
    total = len(SCENES) * SCENE_T + END_T
    frame = 0
    while True:
        for e in pygame.event.get():
            if e.type in (pygame.QUIT, pygame.MOUSEBUTTONDOWN, pygame.KEYDOWN):
                return False
        t = frame / FPS
        if t >= total:
            return True
        s_idx = int(t // SCENE_T)
        if s_idx >= len(SCENES):                      # oxirgi karta
            if scene != len(SCENES):
                scene = len(SCENES)
                screen.fill((0, 0, 0))
                text_center(CHANNEL, font_big, H * 0.44)
                text_center("Python Art  -  Follow for more", font_small, H * 0.52,
                            (180, 180, 180))
        else:
            local = t - s_idx * SCENE_T
            if s_idx != scene:                        # yangi sahna boshlandi
                scene = s_idx
                n, d = SCENES[scene]
                pts, drawn = curve_points(n, d), 0
                screen.fill((0, 0, 0))
                if SHOW_LABEL:
                    text_center("Rose curve   k = %d/%d" % (n, d), font_small, H * 0.08,
                                (200, 200, 200))
            if local < DRAW_T:                        # chizilib chiqish
                target = int(POINTS * local / DRAW_T)
                for i in range(max(1, drawn), target + 1):
                    for sc, rot, hue in LAYERS:
                        ca, sa = math.cos(rot), math.sin(rot)
                        k = int((i / POINTS * 0.5 + hue + scene * HUE_SHIFT) * 256) % 256
                        p = []
                        for j in (i - 1, i):
                            x, y = pts[j]
                            p.append((CX + R * sc * (x * ca - y * sa),
                                      CY + R * sc * (x * sa + y * ca)))
                        pygame.draw.line(screen, PALETTE[k], p[0], p[1], LINE_W)
                drawn = target
            else:                                     # so'nish
                screen.blit(fade, (0, 0))
        pygame.display.flip()
        clock.tick(FPS)
        frame += 1

while True:
    finished = run_video()
    if not (LOOP and finished):
        break
pygame.quit()
