# ============================================================
#  RING BLOOM - ByteBloomArt (kod #7, pygame)
#  Faqat pygame kerak. Pyroid 3 da Run bosing. To'xtatish: ekranga bosing.
#  Aylanalar halqasi gulga aylanadi: ochiladi, yopiladi, rang oqadi.
#  Ekranga sig'adi (SIZE), boshida chizilib chiqadi (INTRO).
# ============================================================
import math
import colorsys
import pygame

# ---------------- SOZLAMALAR ----------------
SPEED     = 1.0   # umumiy tezlik (0.5 sekin, 2.0 tez)
RINGS     = 3     # halqa qatlamlari (2-4)
CIRCLES   = 36    # har qatlamdagi aylanalar (24-60)
HUE_SPEED = 0.05  # rang almashish tezligi
LINE_W    = 2   # chiziq qalinligi (2 aniq, 3 qalin)
TRAIL     = 100 # iz: kichik = uzun iz (xira), katta = aniq (60-140)
INTRO     = 2.5   # boshida chizilib chiqish (soniya)
SIZE      = 0.42  # shakl o'lchami (0.34 kichik ... 0.44 katta)
FPS       = 30
# --------------------------------------------

pygame.init()
try:
    screen = pygame.display.set_mode((0, 0), pygame.FULLSCREEN)
except Exception:
    screen = pygame.display.set_mode((540, 960))
W, H = screen.get_size()
CX, CY = W / 2, H / 2
R = min(W, H) * SIZE
clock = pygame.time.Clock()

PALETTE = [tuple(int(c * 255) for c in colorsys.hsv_to_rgb(i / 256, 0.85, 1.0))
           for i in range(256)]

fade = pygame.Surface((W, H))
fade.fill((0, 0, 0))
fade.set_alpha(TRAIL)

def ease(x):
    x = max(0.0, min(1.0, x))
    return x * x * (3 - 2 * x)

screen.fill((0, 0, 0))
frame = 0
running = True
while running:
    for e in pygame.event.get():
        if e.type in (pygame.QUIT, pygame.MOUSEBUTTONDOWN, pygame.KEYDOWN):
            running = False

    t = frame / FPS * SPEED
    prog = ease(t / INTRO) if INTRO > 0 else 1.0
    screen.blit(fade, (0, 0))

    for j in range(RINGS):
        direction = 1 if j % 2 == 0 else -1
        # aylanalar markazi turgan orbita va aylana radiusi "nafas oladi"
        orbit = (0.50 - 0.12 * j) + 0.10 * math.sin(t * 0.5 + j * 1.3)
        rad = (0.40 - 0.07 * j) + 0.08 * math.sin(t * 0.7 + j * 2.0)
        spin = t * 0.25 * direction + j * 0.3
        shown = max(1, int(CIRCLES * prog))          # chizilib chiqish
        for n in range(shown):
            a = 2 * math.pi * n / CIRCLES + spin
            x = CX + R * orbit * prog * math.cos(a)
            y = CY + R * orbit * prog * math.sin(a)
            k = int((n / CIRCLES + j * 0.25 + t * HUE_SPEED) * 256) % 256
            r = max(2, int(R * rad * prog))
            pygame.draw.circle(screen, PALETTE[k], (int(x), int(y)), r, LINE_W)

    pygame.display.flip()
    clock.tick(FPS)
    frame += 1

pygame.quit()
