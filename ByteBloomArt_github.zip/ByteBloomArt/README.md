# ByteBloomArt - Python Generative Art

Mandalas and math art drawn live with Python. Every effect is one short script
you can run, tweak, and screen-record.

YouTube: **@ByteBloomArt** - new Python art Shorts every day.

## Effects

| File | What it does |
|------|--------------|
| `01_lissajous_mandala.py` | Morphing Lissajous curves with 6-fold symmetry |
| `02_ring_bloom.py` | Rings of circles that bloom and breathe |
| `03_rose_evolution.py` | Rose curves `r = cos(k*theta)` drawn one after another |
| `04_mandala_genesis.py` | A 7-layer mandala built from nothing (about 70 s) |
| `05_mandala_tunnel.py` | Hypnotic endless mandala tunnel (20 s, Shorts-ready) |

## Run

Only `pygame` is needed.

```
pip install pygame
python 05_mandala_tunnel.py
```

On Android: open any file in **Pydroid 3** and press Run.
Tap the screen to stop.

## Tweak

Every script has a settings block at the top (`SPEED`, `SIZE`, `LINE_W`, ...).
Change a number, run again.

Tips: if it is slow on your device lower the point/layer counts;
if the shape touches the screen edge lower `SIZE`.

## License

MIT - free to use, modify and share. A credit to @ByteBloomArt is appreciated.
