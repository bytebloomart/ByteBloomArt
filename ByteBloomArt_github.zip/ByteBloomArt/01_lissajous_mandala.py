# ============================================================
#  LISSAJOUS WAVE MANDALA v2 - ByteBloomArt (pygame)
#  Faqat pygame kerak. Pyroid 3 da Run bosing.
#  To'xtatish: ekranga bosing.
#  v2: boshida chizilib chiqadi, shakli doim o'zgarib turadi.
# ============================================================
import math
import colorsys
import pygame

# ---------------- SOZLAMALAR ----------------
SPEED     = 1.0    # umumiy tezlik (0.5 sekin, 2.0 tez)
LAYERS    = 3      # qatlamlar (2-5). Sekin bo'lsa kamaytiring
SYMMETRY  = 6      # nusxalar soni (4-10)
POINTS    = 160    # silliqlik (100-250)
HUE_SPEED = 0.04   # rang almashish tezligi
LINE_W    = 2      # chiziq qalinligi
TRAIL     = 34     # iz: kichik = uzun iz (15-80)
INTRO     = 4.0    # boshida chizilib chiqish (soniya)
MORPH     = 1.0    # shakl o'zgarish tezligi (0.5 sekin, 2 tez)
FPS       = 30
# --------------------------------------------

pygame.init()
try:
    screen = pygame.display.set_mode((0, 0), pygame.FULLSCREEN)
except Exception:
    screen = pygame.display.set_mode((540, 960))
W, H = screen.get_size()
CX, CY = W / 2, H / 2
SIZE = 0.36      # shakl o'lchami (0.30 kichik ... 0.40 katta)
R = min(W, H) * SIZE
clock = pygame.time.Clock()

PALETTE = [tuple(int(c * 255) for c in colorsys.hsv_to_rgb(i / 256, 0.8, 1.0))
           for i in range(256)]

FA = [3, 2, 5, 4, 3][:LAYERS]            # x chastotalari (butun)
FB = [4, 5, 6, 7, 5][:LAYERS]            # y chastotalari (butun)
RAD = [1.0, 0.72, 0.48, 0.85, 0.6][:LAYERS]
T = [2 * math.pi * n / POINTS for n in range(POINTS + 1)]

fade = pygame.Surface((W, H))
fade.fill((0, 0, 0))
fade.set_alpha(TRAIL)

def ease(x):                       # silliq 0 -> 1
    x = max(0.0, min(1.0, x))
    return x * x * (3 - 2 * x)

screen.fill((0, 0, 0))
frame = 0
running = True
while running:
    for e in pygame.event.get():
        if e.type in (pygame.QUIT, pygame.MOUSEBUTTONDOWN, pygame.KEYDOWN):
            running = False

    time = frame / FPS * SPEED
    prog = ease(time / INTRO) if INTRO > 0 else 1.0   # kirish jarayoni
    screen.blit(fade, (0, 0))
    m = time * MORPH

    for i in range(LAYERS):
        # x va y fazalari turli tezlikda siljiydi -> shakl haqiqatan o'zgaradi
        px = m * (0.55 + 0.17 * i)
        py = 1.3 * math.sin(m * 0.35 + i * 1.7)
        r = R * RAD[i] * prog * (1 + 0.18 * math.sin(m * 0.7 + i * 2.1))
        base = [(r * math.sin(FA[i] * t + px), r * math.sin(FB[i] * t + py)) for t in T]
        last = max(2, int(POINTS * prog))              # chizilib chiqish

        for s in range(SYMMETRY):
            a = 2 * math.pi * s / SYMMETRY + time * 0.06 * (1 if i % 2 == 0 else -1)
            ca, sa = math.cos(a), math.sin(a)
            pts = [(CX + x * ca - y * sa, CY + x * sa + y * ca) for x, y in base]
            for n in range(last):
                k = int((n / POINTS * 0.8 + i * 0.28 + time * HUE_SPEED) * 256) % 256
                pygame.draw.line(screen, PALETTE[k], pts[n], pts[n + 1], LINE_W)

    pygame.display.flip()
    clock.tick(FPS)
    frame += 1

pygame.quit()
