# ============================================================
#  MANDALA TUNNEL - ByteBloomArt (kod #10, pygame) - QISQA SHORTS ~20 soniya
#  Faqat pygame kerak. Pyroid 3 da Run bosing. To'xtatish: ekranga bosing.
#
#  Markazdan to'xtovsiz gul halqalari chiqib, ekran chetiga qarab tezlashib
#  ochilib boradi - hipnotik "tunnel". Birinchi kadrdan to'la ekran (bo'sh
#  boshlanish yo'q = kuchli hook). Qora fon, qalin chiziqlar, shakl
#  ekran chetlariga tegmaydi.
# ============================================================
import math
import colorsys
import pygame

# ---------------- SOZLAMALAR ----------------
DURATION  = 20.0   # video uzunligi (soniya). Shorts uchun 15-25 yaxshi
INTERVAL  = 0.8    # yangi halqa paydo bo'lish oralig'i (kichik = zichroq)
LIFE      = 11.0   # halqa markazdan chetgacha yetish vaqti (soniya)
PETALS    = 12     # har halqadagi barglar soni (8-16)
SPEED     = 1.0    # umumiy tezlik
SPIN      = 0.35   # halqalarning aylanish tezligi
HUE_SPEED = 0.03   # rang oqish tezligi
LINE_W    = 2      # chiziq qalinligi (2 aniq, 3 qalin)
SIZE      = 0.40   # o'lcham (0.34 kichik ... 0.44 katta)
HOOK_TEXT = "Watch the center"   # birinchi soniyalardagi yozuv ("" = yo'q)
HOOK_T    = 2.5    # yozuv ko'rinish vaqti (soniya)
LOOP      = False  # True -> tugagach boshidan boshlanadi
FPS       = 30
# --------------------------------------------

TAU = 2 * math.pi

def petal_shape(m=9):
    """Bitta barg konturi (birlik o'lchamda, x o'qi bo'ylab)."""
    pts = []
    for j in range(m):
        s = j / (m - 1)
        pts.append((0.55 + 0.45 * s, 0.16 * math.sin(math.pi * s) ** 0.9))
    for j in range(m):
        s = 1 - j / (m - 1)
        pts.append((0.55 + 0.45 * s, -0.16 * math.sin(math.pi * s) ** 0.9))
    return pts

PETAL = petal_shape()

def rings_at(ts, hue_t, R):
    """Vaqt ts dagi barcha halqalar: [(rang, [chiziqlar...]), ...] (eng kattasi birinchi)."""
    out = []
    k_max = int(ts // INTERVAL)
    k_min = max(0, int((ts - LIFE) // INTERVAL))
    for k in range(k_min, k_max + 1):
        age = ts - k * INTERVAL
        if age < 0 or age >= LIFE:
            continue
        u = age / LIFE
        r = R * u ** 1.35                              # tezlashib kengayadi
        if r < 3:
            continue
        direction = 1 if k % 2 == 0 else -1
        phi = direction * age * SPIN + (k % 2) * math.pi / PETALS
        bright = min(1.0, age * 2.5) * (1 - u ** 5)    # kirishda yonadi, chetda so'nadi
        rgb = colorsys.hsv_to_rgb((k * 0.06 + hue_t * HUE_SPEED) % 1.0, 0.8, bright)
        col = (int(rgb[0] * 255), int(rgb[1] * 255), int(rgb[2] * 255))
        polys = []
        for p in range(PETALS):
            a = phi + TAU * p / PETALS
            ca, sa = math.cos(a), math.sin(a)
            polys.append([(r * (x * ca - y * sa), r * (x * sa + y * ca)) for x, y in PETAL])
        out.append((col, polys))
    out.reverse()                                       # katta (eski) halqa pastda
    return out

def main():
    pygame.init()
    try:
        screen = pygame.display.set_mode((0, 0), pygame.FULLSCREEN)
    except Exception:
        screen = pygame.display.set_mode((540, 960))
    W, H = screen.get_size()
    CX, CY = W / 2, H / 2
    R = min(W, H) * SIZE
    clock = pygame.time.Clock()
    font = pygame.font.Font(None, int(W * 0.08))
    hook_img = font.render(HOOK_TEXT, True, (255, 255, 255)) if HOOK_TEXT else None

    while True:
        frame = 0
        running = True
        while running:
            for e in pygame.event.get():
                if e.type in (pygame.QUIT, pygame.MOUSEBUTTONDOWN, pygame.KEYDOWN):
                    pygame.quit()
                    return
            t = frame / FPS * SPEED
            if t >= DURATION:
                break
            ts = t + LIFE                  # oldindan to'ldirilgan: birinchi kadrdan to'liq ekran
            screen.fill((0, 0, 0))
            pulse = 1 + 0.02 * math.sin(t * 3.0)              # yengil "yurak urishi"
            for col, polys in rings_at(ts, t, R * pulse):
                for poly in polys:
                    pygame.draw.lines(screen, col, True,
                                      [(CX + x, CY + y) for x, y in poly], LINE_W)
            # markazdagi yorqin nuqta
            pygame.draw.circle(screen, (255, 255, 255), (int(CX), int(CY)),
                               max(3, int(R * 0.02 * (1 + 0.5 * math.sin(t * 6)))))
            if hook_img is not None and t < HOOK_T:
                screen.blit(hook_img, (CX - hook_img.get_width() / 2, H * 0.12))
            pygame.display.flip()
            clock.tick(FPS)
            frame += 1
        if not LOOP:
            break
    pygame.quit()

if __name__ == "__main__":
    main()
